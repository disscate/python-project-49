### Hexlet tests and linter status:
[![Actions Status](https://github.com/disscate/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/disscate/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/384781d62be6cc8c362c/maintainability)](https://codeclimate.com/github/disscate/python-project-49/maintainability)
